//
//  Copyright © 2017 Bowtie. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double FlagKitVersionNumber;
FOUNDATION_EXPORT const unsigned char FlagKitVersionString[];
